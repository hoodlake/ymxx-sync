﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Text.RegularExpressions;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace GETListFromString
{
    public partial class FrmMain : Form
    {
        /// <summary>
        /// 文本框最多文本大小
        /// </summary>
        private int txtLength = 80000;
        private StringBuilder sb;

        public FrmMain()
        {
            InitializeComponent();
        }

        private void btn_Click(object sender, EventArgs e)
        {
            DelegatedControlUpdate(txtPre, args =>
            {
                txtAfter.Text = null;
                txtAfter.Text = ConvertText(txtPre.Text);
            }, null);
        }

        private string ConvertText(string text)
        {
            string strNoBlank = text.Trim();
            string[] strs = strNoBlank.Split('\n');

            List<string> list = new List<string>(strs);

            list.RemoveAll(delegate(string temp)
            {
                if (temp.Contains('-'))
                {
                    return true;
                }

                return false;
            });

            string strContent = String.Join(";", list.ToArray());

            string[] contents = strContent.Split(';');
            list = new List<string>(contents);
            list.RemoveAll(delegate(string temp)
            {
                if (temp.Equals("\r"))
                {
                    return true;
                }
                if (string.IsNullOrEmpty(temp))
                {
                    return true;
                }
                return false;
            });

            List<string> list_key = new List<string>();
            Hashtable hash = new Hashtable();

            foreach (string content in list)
            {
                string regex = @"[0-9]*";
                Match mstr = Regex.Match(content, regex);
                foreach (Group group in mstr.Groups)
                {
                    string temp = group.Value;
                    int i;
                    if (Int32.TryParse(temp, out i))
                    {
                        if (!hash.ContainsKey(temp))
                        {
                            hash.Add(temp, temp);
                            list_key.Add(temp);
                        }

                    }
                }
            }

            hash.Clear();

            return String.Join("\r", list_key.ToArray()); ;
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "文本文档 (*.txt)|*.txt";
            ofd.Multiselect = false;
            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtFile.Text = ofd.FileName;
                Thread t = new Thread(new ThreadStart(ReadTxt));
                t.Start();
            }
        }

        /// <summary>
        /// 从文本文件中读取内容
        /// </summary>
        private void ReadTxt()
        {
            DelegatedControlUpdate(txtPre, args =>
            {
                lbState.Visible = true;
                btnSelect.Enabled = false;

                txtPre.Text = null;
                txtAfter.Text = null;
            }, null);

            sb = new StringBuilder();

            using (StreamReader sr = new StreamReader(txtFile.Text,
                Encoding.GetEncoding("GB2312")))
            {
                String line;
                while ((line = sr.ReadLine()) != null)
                {
                    sb.Append("\r");
                    sb.Append(line);
                }
            }

            DelegatedControlUpdate(txtPre, args =>
            {
                DisplayContent(sb);
                lbState.Visible = false;
                btnSelect.Enabled = true;
                btnSelect.Text = "...";
            }, null);
        }

        /// <summary>
        /// 分页显示内容
        /// </summary>
        /// <param name="sb"></param>
        /// <param name="idx"></param>
        private void DisplayContent(StringBuilder sb, int idx = 1)
        {
            int i = sb.Length;
            int count = i / txtLength;
            txtYS.Text = count.ToString();
            txtPre.Text = null;
            string s = sb.ToString((idx - 1) * txtLength, txtLength);
            txtPre.AppendText(s);
        }

        #region 委托跨线程修改控件属性

        private delegate void ParameterizedControlUpdate(params object[] args);
        private delegate void ControlUpdateDelegate(Component c,
            ParameterizedControlUpdate callback,
            params object[] args);
        private void DelegatedControlUpdate(Component c,
            ParameterizedControlUpdate callback,
            params object[] args)
        {
            Control target = (c is Control) ? (c as Control) : this;
            if (target.InvokeRequired)
            {
                ControlUpdateDelegate d = DelegatedControlUpdate;
                target.Invoke(d, new object[] { c, callback, args });
            }
            else
            {
                callback(args);
            }
        }

        #endregion

        #region //翻页

        private void btnSY_Click(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(txtIdx.Text);
            txtIdx.Text = i < 2 ? "1" : (i - 1).ToString();
        }

        private void btnXY_Click(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(txtIdx.Text);
            txtIdx.Text = i >= Convert.ToInt32(txtYS.Text) ? txtYS.Text : (i + 1).ToString();
        }

        private void txtIdx_TextChanged(object sender, EventArgs e)
        {
            DisplayContent(sb, Convert.ToInt32(txtIdx.Text));
        }

        #endregion

        #region //控制TextBox只能输入数字
        /// <summary>
        /// 控制TextBox只能输入数字
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtIdx_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 0x20) e.KeyChar = (char)0;  //禁止空格键
            if ((e.KeyChar == 0x2D) && (((TextBox)sender).Text.Length == 0)) return;   //处理负数
            if (e.KeyChar > 0x20)
            {
                try
                {
                    double.Parse(((TextBox)sender).Text + e.KeyChar.ToString());
                }
                catch
                {
                    e.KeyChar = (char)0;   //处理非法字符
                }
            }
        }

        #endregion
    }
}
