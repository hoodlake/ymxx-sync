﻿namespace GETListFromString
{
    partial class FrmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panelPre = new System.Windows.Forms.Panel();
            this.panelSHA = new System.Windows.Forms.Panel();
            this.txtPre = new System.Windows.Forms.RichTextBox();
            this.panelXIA = new System.Windows.Forms.Panel();
            this.txtYS = new System.Windows.Forms.TextBox();
            this.txtIdx = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnXY = new System.Windows.Forms.Button();
            this.btnSY = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbState = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtAfter = new System.Windows.Forms.RichTextBox();
            this.btn = new System.Windows.Forms.Button();
            this.txtFile = new System.Windows.Forms.TextBox();
            this.btnSelect = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panelPre.SuspendLayout();
            this.panelSHA.SuspendLayout();
            this.panelXIA.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.splitContainer1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(619, 384);
            this.panel1.TabIndex = 0;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.groupBox2);
            this.splitContainer1.Size = new System.Drawing.Size(619, 384);
            this.splitContainer1.SplitterDistance = 400;
            this.splitContainer1.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panelPre);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(400, 384);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "转换前";
            // 
            // panelPre
            // 
            this.panelPre.Controls.Add(this.lbState);
            this.panelPre.Controls.Add(this.panelSHA);
            this.panelPre.Controls.Add(this.panelXIA);
            this.panelPre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPre.Location = new System.Drawing.Point(3, 17);
            this.panelPre.Name = "panelPre";
            this.panelPre.Size = new System.Drawing.Size(394, 364);
            this.panelPre.TabIndex = 1;
            // 
            // panelSHA
            // 
            this.panelSHA.Controls.Add(this.txtPre);
            this.panelSHA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelSHA.Location = new System.Drawing.Point(0, 0);
            this.panelSHA.Name = "panelSHA";
            this.panelSHA.Size = new System.Drawing.Size(394, 331);
            this.panelSHA.TabIndex = 7;
            // 
            // txtPre
            // 
            this.txtPre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPre.Location = new System.Drawing.Point(0, 0);
            this.txtPre.Name = "txtPre";
            this.txtPre.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.txtPre.Size = new System.Drawing.Size(394, 331);
            this.txtPre.TabIndex = 7;
            this.txtPre.Text = "";
            // 
            // panelXIA
            // 
            this.panelXIA.Controls.Add(this.txtYS);
            this.panelXIA.Controls.Add(this.txtIdx);
            this.panelXIA.Controls.Add(this.label3);
            this.panelXIA.Controls.Add(this.btnXY);
            this.panelXIA.Controls.Add(this.btnSY);
            this.panelXIA.Controls.Add(this.label2);
            this.panelXIA.Controls.Add(this.label1);
            this.panelXIA.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelXIA.Location = new System.Drawing.Point(0, 331);
            this.panelXIA.Name = "panelXIA";
            this.panelXIA.Size = new System.Drawing.Size(394, 33);
            this.panelXIA.TabIndex = 6;
            // 
            // txtYS
            // 
            this.txtYS.Location = new System.Drawing.Point(331, 6);
            this.txtYS.Name = "txtYS";
            this.txtYS.ReadOnly = true;
            this.txtYS.Size = new System.Drawing.Size(60, 21);
            this.txtYS.TabIndex = 7;
            // 
            // txtIdx
            // 
            this.txtIdx.Location = new System.Drawing.Point(107, 6);
            this.txtIdx.Name = "txtIdx";
            this.txtIdx.Size = new System.Drawing.Size(50, 21);
            this.txtIdx.TabIndex = 6;
            this.txtIdx.Text = "1";
            this.txtIdx.TextChanged += new System.EventHandler(this.txtIdx_TextChanged);
            this.txtIdx.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdx_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(287, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "总页数:";
            // 
            // btnXY
            // 
            this.btnXY.Location = new System.Drawing.Point(186, 4);
            this.btnXY.Name = "btnXY";
            this.btnXY.Size = new System.Drawing.Size(75, 23);
            this.btnXY.TabIndex = 3;
            this.btnXY.Text = "下一页";
            this.btnXY.UseVisualStyleBackColor = true;
            this.btnXY.Click += new System.EventHandler(this.btnXY_Click);
            // 
            // btnSY
            // 
            this.btnSY.Location = new System.Drawing.Point(3, 4);
            this.btnSY.Name = "btnSY";
            this.btnSY.Size = new System.Drawing.Size(75, 23);
            this.btnSY.TabIndex = 2;
            this.btnSY.Text = "上一页";
            this.btnSY.UseVisualStyleBackColor = true;
            this.btnSY.Click += new System.EventHandler(this.btnSY_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(163, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "页";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "第";
            // 
            // lbState
            // 
            this.lbState.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbState.Font = new System.Drawing.Font("宋体", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbState.Location = new System.Drawing.Point(0, 0);
            this.lbState.Name = "lbState";
            this.lbState.Size = new System.Drawing.Size(394, 331);
            this.lbState.TabIndex = 8;
            this.lbState.Text = "正在读取数据...";
            this.lbState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbState.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtAfter);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(215, 384);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "转换后";
            // 
            // txtAfter
            // 
            this.txtAfter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtAfter.Location = new System.Drawing.Point(3, 17);
            this.txtAfter.Name = "txtAfter";
            this.txtAfter.Size = new System.Drawing.Size(209, 364);
            this.txtAfter.TabIndex = 0;
            this.txtAfter.Text = "";
            this.txtAfter.WordWrap = false;
            // 
            // btn
            // 
            this.btn.Location = new System.Drawing.Point(507, 390);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(93, 23);
            this.btn.TabIndex = 1;
            this.btn.Text = "开始转换";
            this.btn.UseVisualStyleBackColor = true;
            this.btn.Click += new System.EventHandler(this.btn_Click);
            // 
            // txtFile
            // 
            this.txtFile.Location = new System.Drawing.Point(3, 392);
            this.txtFile.Name = "txtFile";
            this.txtFile.ReadOnly = true;
            this.txtFile.Size = new System.Drawing.Size(394, 21);
            this.txtFile.TabIndex = 2;
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(403, 390);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(44, 23);
            this.btnSelect.TabIndex = 3;
            this.btnSelect.Text = "...";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(619, 422);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.txtFile);
            this.Controls.Add(this.btn);
            this.Controls.Add(this.panel1);
            this.Name = "FrmMain";
            this.Text = "获取字符串中的有效数组";
            this.panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panelPre.ResumeLayout(false);
            this.panelSHA.ResumeLayout(false);
            this.panelXIA.ResumeLayout(false);
            this.panelXIA.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn;
        private System.Windows.Forms.RichTextBox txtAfter;
        private System.Windows.Forms.TextBox txtFile;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Panel panelPre;
        private System.Windows.Forms.Panel panelXIA;
        private System.Windows.Forms.TextBox txtIdx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnXY;
        private System.Windows.Forms.Button btnSY;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelSHA;
        private System.Windows.Forms.RichTextBox txtPre;
        private System.Windows.Forms.Label lbState;
        private System.Windows.Forms.TextBox txtYS;

    }
}

